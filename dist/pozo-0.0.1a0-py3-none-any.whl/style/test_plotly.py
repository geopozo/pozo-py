import pozo.style.plotly
import pytest

def test_PlotlyRenderer():
    pozo.style.plotly.PlotlyRenderer()
